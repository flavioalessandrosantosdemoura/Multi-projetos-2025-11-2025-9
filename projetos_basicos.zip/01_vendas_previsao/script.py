import pandas as pd
from sklearn.linear_model import LinearRegression
# exemplo mínimo
