import pandas as pd
# análise básica RH
