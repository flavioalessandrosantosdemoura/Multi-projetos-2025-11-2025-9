# KPIs RH
Dashboard de RH.