# Sentimentos
NLP simples.