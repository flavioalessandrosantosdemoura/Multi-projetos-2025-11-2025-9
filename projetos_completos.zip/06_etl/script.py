import pandas as pd
# ETL simples
