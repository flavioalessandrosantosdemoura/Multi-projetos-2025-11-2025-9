# ETL
Pipeline simples.