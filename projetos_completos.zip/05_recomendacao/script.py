import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity
