# Fraude
Detecção simples.