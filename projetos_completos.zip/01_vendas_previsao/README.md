# Projeto Vendas
Previsão básica de vendas.