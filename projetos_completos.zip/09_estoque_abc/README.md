# Estoque ABC
Classificação ABC.