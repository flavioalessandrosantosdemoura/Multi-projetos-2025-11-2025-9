# Logística
Análises básicas.