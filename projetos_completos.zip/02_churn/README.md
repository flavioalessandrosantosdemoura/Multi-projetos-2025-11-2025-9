# Projeto Churn
Modelo simples.